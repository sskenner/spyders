### mainprogam.py
### IMPORTS ANOTHER MODULE
import moduletest

### USING AN IMPORTED MODULE
# Use the form modulename.itemname
# Examples:
print(moduletest.ageofqueen)
cfcpiano = moduletest.Piano()
cfcpiano.printdetails()